import "./styles.css";

let isEnterKeyPressed = false;
let playerOneScore = 0;
let playerTwoScore = 0;
let dirX = 1;
let dirY = 1;
// accessing elements
let app = document.getElementById("app");
let rod1 = document.getElementById("rod-01");
let rod2 = document.getElementById("rod-02");
let ball = document.getElementById("ball");
let message = document.getElementById("message");

let gameBoardWidth = app.clientWidth;
let rodOneOffsetWidth = rod1.offsetWidth;
let rodTwoOffsetWidth = rod1.offsetWidth;
let speed = 7; // in px

// show alert of highest score
let alertMessage = JSON.parse(localStorage.getItem("HIGHEST_SCORE"));

if (alertMessage) {
  alert(
    `${alertMessage.playerName} has maximum score of ${alertMessage.score}`
  );
} else {
  alert("This is your first time");
}

// positioning rods and ball to center
rod1.style.left =
  Math.floor(gameBoardWidth / 2) - Math.floor(rodOneOffsetWidth / 2) + "px";
rod2.style.left =
  Math.floor(gameBoardWidth / 2) - Math.floor(rodTwoOffsetWidth / 2) + "px";
ball.style.left =
  Math.floor(gameBoardWidth / 2) - Math.floor(ball.offsetWidth / 2) + "px";
ball.style.top = Math.floor(rod1.offsetHeight) + 2 + "px";

// start game on pressing enter Key
// and adding moving functionality to the rods
window.addEventListener("keydown", function (event) {
  const KEY = event.key.toLowerCase();
  let rodleft = parseInt(rod1.style.left);

  //start game
  if (KEY === "enter") {
    isEnterKeyPressed = true;
    ballMovement();
  }

  // move the rods left
  if (isEnterKeyPressed && KEY === "a" && rodleft >= 0) {
    rod1.style.left = rodleft - speed + "px";
    rod2.style.left = rodleft + "px";
  }

  // move the rods right
  if (isEnterKeyPressed && KEY === "d" && rodleft <= gameBoardWidth - 206) {
    rod1.style.left = rodleft + speed + "px";
    rod2.style.left = rodleft + speed + "px";
  }
});

// ball movement animation
function ballMovement() {
  // setting ball movement Interval
  let movingAnimation = setInterval(function () {
    let ballValues = ball.getBoundingClientRect();
    let rodOneValues = rod1.getBoundingClientRect();
    let rodTwoValues = rod2.getBoundingClientRect();

    // checks if ball is collide with rod 2.
    // changes Y direction if collide
    if (ballValues.bottom >= rodTwoValues.top) {
      if (
        ballValues.right >= rodTwoValues.left &&
        ballValues.left <= rodTwoValues.right
      ) {
        // changes y direction
        //increase score to rod-02
        dirY = -1;
        playerTwoScore++;
      } else {
        // rod 2 lose the game
        clearInterval(movingAnimation);
        // display alert
        alert(
          "rod 1 wins the match with score of " +
            playerOneScore +
            " ,Max Score is " +
            (alertMessage ? alertMessage.score : 0)
        );
        // reset game
        reset(
          Math.floor(rod2.offsetTop) - ballValues.height - 2 + "px",
          playerOneScore,
          "rod1"
        );
      }
    }

    // checks if ball is collide with rod 1.as
    // changes Y direction if collide
    if (ballValues.top <= rodOneValues.bottom) {
      if (
        ballValues.right >= rodOneValues.left &&
        ballValues.left <= rodOneValues.right
      ) {
        // changes y direction
        //increase score to rod-01
        dirY = 1;
        playerOneScore++;
      } else {
        //  rod 1 lose the game
        clearInterval(movingAnimation);
        //display alert
        alert(
          "rod 2 wins the match with score of " +
            playerTwoScore +
            " ,Max Score is " +
            (alertMessage ? alertMessage.score : 0)
        );
        // reset game
        reset(Math.floor(rod1.offsetHeight) + 2 + "px", playerTwoScore, "rod2");
      }
    }

    // changes X direction if collides with the walls.
    if (ballValues.left <= 0) {
      dirX = 1;
    }

    if (ballValues.right >= gameBoardWidth) {
      dirX = -1;
    }

    // updating ball positions
    ball.style.left = parseInt(ball.style.left) + dirX + "px";
    ball.style.top = parseInt(ball.style.top) + dirY + "px";

    message.innerHTML = `Player 1: ${playerOneScore}  &nbsp&nbsp&nbsp&nbsp   Player 2: ${playerTwoScore}`;
  }, 16);
}

//reset game
function reset(ballPosition, winnerScore, winnerName) {
  let highestScore = {
    playerName: "",
    score: 0
  };

  if (alertMessage === null || winnerScore > alertMessage.score) {
    highestScore.score = winnerScore;
    highestScore.playerName = winnerName;
    localStorage.setItem("HIGHEST_SCORE", JSON.stringify(highestScore));
  }

  if (winnerName === "rod1") {
    dirX = 1;
    dirY = -1;
  } else {
    dirX = 1;
    dirY = 1;
  }

  isEnterKeyPressed = false;
  playerOneScore = 0;
  playerTwoScore = 0;
  alertMessage = JSON.parse(localStorage.getItem("HIGHEST_SCORE"));
  ball.style.top = ballPosition;
  message.innerHTML = 'Please Press "Enter" Key to Start Game';
  rod1.style.left =
    Math.floor(gameBoardWidth / 2) - Math.floor(rodOneOffsetWidth / 2) + "px";
  rod2.style.left =
    Math.floor(gameBoardWidth / 2) - Math.floor(rodTwoOffsetWidth / 2) + "px";
  ball.style.left =
    Math.floor(gameBoardWidth / 2) - Math.floor(ball.offsetWidth / 2) + "px";
}
